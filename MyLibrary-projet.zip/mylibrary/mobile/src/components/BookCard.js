import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import Cover from './Cover';
import { colors, radius } from '../theme';

// Ligne de liste : couverture, titre, auteur, catégorie et bouton favori
export default function BookCard({ book, onPress, isFavorite, onToggleFavorite }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.card, pressed && styles.pressed]}>
      <Cover book={book} />
      <View style={styles.info}>
        <Text style={styles.title} numberOfLines={2}>
          {book.titre}
        </Text>
        <Text style={styles.author} numberOfLines={1}>
          {book.auteur}
          {book.annee ? ` · ${book.annee}` : ''}
        </Text>
        <View style={styles.badge}>
          <Text style={styles.badgeText}>{book.categorie}</Text>
        </View>
      </View>
      {onToggleFavorite && (
        <Pressable onPress={onToggleFavorite} hitSlop={10} style={styles.heart}>
          <Ionicons
            name={isFavorite ? 'heart' : 'heart-outline'}
            size={26}
            color={isFavorite ? colors.danger : colors.muted}
          />
        </Pressable>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: radius,
    padding: 12,
    marginBottom: 10,
  },
  pressed: { opacity: 0.8 },
  info: { flex: 1, marginLeft: 12 },
  title: { fontSize: 16, fontWeight: '700', color: colors.text },
  author: { fontSize: 13, color: colors.muted, marginTop: 2 },
  badge: {
    alignSelf: 'flex-start',
    backgroundColor: colors.tint,
    borderRadius: 10,
    paddingHorizontal: 10,
    paddingVertical: 3,
    marginTop: 8,
  },
  badgeText: { fontSize: 12, color: colors.primary, fontWeight: '600' },
  heart: { padding: 6 },
});
