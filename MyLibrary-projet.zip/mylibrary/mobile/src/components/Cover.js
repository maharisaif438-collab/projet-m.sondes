import React from 'react';
import { Image, Text, View } from 'react-native';

const PALETTE = ['#2E7D68', '#3F5E8C', '#C8553D', '#8A6F3E', '#5C8A9E', '#7A4E8C'];

const colorFor = (text = '') =>
  PALETTE[[...text].reduce((sum, c) => sum + c.charCodeAt(0), 0) % PALETTE.length];

// Couverture du livre : l'image si elle existe, sinon une pastille colorée avec l'initiale
export default function Cover({ book, width = 60, height = 84, radius = 8 }) {
  if (book && book.image) {
    return (
      <Image
        source={{ uri: book.image }}
        style={{ width, height, borderRadius: radius, backgroundColor: '#E5E9E7' }}
        resizeMode="cover"
      />
    );
  }
  const initial = ((book && book.titre) || '?').charAt(0).toUpperCase();
  return (
    <View
      style={{
        width,
        height,
        borderRadius: radius,
        backgroundColor: colorFor(book && book.titre),
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      <Text style={{ color: '#fff', fontSize: Math.round(width * 0.45), fontWeight: '700' }}>
        {initial}
      </Text>
    </View>
  );
}
