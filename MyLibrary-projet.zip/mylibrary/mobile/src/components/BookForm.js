import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { ImageManipulator, SaveFormat } from 'expo-image-manipulator';
import Cover from './Cover';
import CategoryChips from './CategoryChips';
import * as api from '../api';
import { colors, radius } from '../theme';

const DEFAULT_CATEGORIES = ['Roman', 'Science-fiction', 'Histoire', 'Informatique', 'Poésie', 'Jeunesse'];

// Formulaire partagé par les écrans "Ajouter un livre" et "Modifier un livre"
export default function BookForm({ initial, submitLabel, onSubmit }) {
  const [titre, setTitre] = useState(initial?.titre ?? '');
  const [auteur, setAuteur] = useState(initial?.auteur ?? '');
  const [categorie, setCategorie] = useState(initial?.categorie ?? '');
  const [annee, setAnnee] = useState(initial?.annee ? String(initial.annee) : '');
  const [description, setDescription] = useState(initial?.description ?? '');
  const [image, setImage] = useState(initial?.image ?? '');
  const [categories, setCategories] = useState(DEFAULT_CATEGORIES);
  const [submitting, setSubmitting] = useState(false);
  const [processingPhoto, setProcessingPhoto] = useState(false);

  useEffect(() => {
    api
      .getCategories()
      .then((remote) => {
        const merged = [...new Set([...DEFAULT_CATEGORIES, ...remote])];
        setCategories(merged.sort((a, b) => a.localeCompare(b, 'fr')));
      })
      .catch(() => {});
  }, []);

  // Fonctionnalité native : photographier la couverture avec la caméra
  const takePhoto = async () => {
    try {
      const permission = await ImagePicker.requestCameraPermissionsAsync();
      if (!permission.granted) {
        Alert.alert(
          'Permission refusée',
          "Autorisez l'accès à la caméra dans les réglages pour photographier la couverture."
        );
        return;
      }
      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ['images'],
        allowsEditing: true,
        aspect: [3, 4],
        quality: 0.8,
      });
      if (result.canceled || !result.assets || !result.assets.length) return;

      setProcessingPhoto(true);
      // Réduction de la photo (400 px de large, JPEG) avant de l'envoyer à l'API en base64
      const context = ImageManipulator.manipulate(result.assets[0].uri);
      context.resize({ width: 400 });
      const rendered = await context.renderAsync();
      const saved = await rendered.saveAsync({ format: SaveFormat.JPEG, compress: 0.6, base64: true });
      setImage(`data:image/jpeg;base64,${saved.base64}`);
    } catch (e) {
      Alert.alert('Caméra indisponible', "Impossible de prendre ou de traiter la photo : " + e.message);
    } finally {
      setProcessingPhoto(false);
    }
  };

  const submit = async () => {
    if (!titre.trim() || !auteur.trim() || !categorie.trim()) {
      Alert.alert('Champs manquants', 'Le titre, l\'auteur et la catégorie sont obligatoires.');
      return;
    }
    const year = annee.trim();
    if (year && !/^\d{1,4}$/.test(year)) {
      Alert.alert('Année invalide', "L'année doit être un nombre, par exemple 1949.");
      return;
    }
    setSubmitting(true);
    try {
      await onSubmit({
        titre: titre.trim(),
        auteur: auteur.trim(),
        categorie: categorie.trim(),
        annee: year ? Number(year) : null,
        description: description.trim(),
        image,
      });
    } catch (e) {
      Alert.alert('Erreur', e.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: colors.bg }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <View style={styles.photoRow}>
          <Cover book={{ titre: titre || '?', image }} width={96} height={128} radius={10} />
          <View style={styles.photoActions}>
            <Pressable style={styles.photoButton} onPress={takePhoto} disabled={processingPhoto}>
              {processingPhoto ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <>
                  <Ionicons name="camera" size={20} color="#fff" />
                  <Text style={styles.photoButtonText}>
                    {image ? 'Reprendre la photo' : 'Photographier la couverture'}
                  </Text>
                </>
              )}
            </Pressable>
            {!!image && (
              <Pressable onPress={() => setImage('')} style={styles.removePhoto}>
                <Text style={styles.removePhotoText}>Retirer la photo</Text>
              </Pressable>
            )}
          </View>
        </View>

        <Text style={styles.label}>Titre *</Text>
        <TextInput style={styles.input} value={titre} onChangeText={setTitre} placeholder="Titre du livre" />

        <Text style={styles.label}>Auteur *</Text>
        <TextInput style={styles.input} value={auteur} onChangeText={setAuteur} placeholder="Nom de l'auteur" />

        <Text style={styles.label}>Catégorie *</Text>
        <View style={styles.chipsWrap}>
          <CategoryChips
            categories={categories}
            selected={categories.includes(categorie) ? categorie : undefined}
            onSelect={(c) => c && setCategorie(c)}
            allLabel="Choisir :"
          />
        </View>
        <TextInput
          style={styles.input}
          value={categorie}
          onChangeText={setCategorie}
          placeholder="ou saisissez une nouvelle catégorie"
        />

        <Text style={styles.label}>Année</Text>
        <TextInput
          style={styles.input}
          value={annee}
          onChangeText={setAnnee}
          placeholder="Ex. 1949"
          keyboardType="number-pad"
          maxLength={4}
        />

        <Text style={styles.label}>Description</Text>
        <TextInput
          style={[styles.input, styles.multiline]}
          value={description}
          onChangeText={setDescription}
          placeholder="Résumé du livre"
          multiline
          textAlignVertical="top"
        />

        <Pressable
          style={[styles.submit, submitting && { opacity: 0.6 }]}
          onPress={submit}
          disabled={submitting}
        >
          {submitting ? <ActivityIndicator color="#fff" /> : <Text style={styles.submitText}>{submitLabel}</Text>}
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  content: { padding: 16, paddingBottom: 40 },
  photoRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  photoActions: { flex: 1, marginLeft: 16 },
  photoButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: colors.primary,
    borderRadius: radius,
    paddingVertical: 12,
    paddingHorizontal: 12,
    minHeight: 46,
  },
  photoButtonText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  removePhoto: { marginTop: 10, alignSelf: 'flex-start' },
  removePhotoText: { color: colors.danger, fontWeight: '600' },
  label: { fontSize: 14, fontWeight: '700', color: colors.dark, marginTop: 14, marginBottom: 6 },
  input: {
    backgroundColor: colors.card,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 11,
    fontSize: 16,
    color: colors.text,
  },
  multiline: { minHeight: 110 },
  chipsWrap: { marginHorizontal: -16, marginTop: -4 },
  submit: {
    backgroundColor: colors.dark,
    borderRadius: radius,
    alignItems: 'center',
    paddingVertical: 15,
    marginTop: 24,
  },
  submitText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
