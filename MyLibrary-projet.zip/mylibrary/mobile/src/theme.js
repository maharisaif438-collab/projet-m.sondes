export const colors = {
  primary: '#2E7D68',
  dark: '#163A32',
  accent: '#E0A82E',
  danger: '#C8553D',
  bg: '#F4F7F6',
  card: '#FFFFFF',
  text: '#1C2623',
  muted: '#6B7A75',
  border: '#DDE5E1',
  tint: '#EDF3F0',
};

export const radius = 14;
