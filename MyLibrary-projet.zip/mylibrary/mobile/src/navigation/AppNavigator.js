import React from 'react';
import { NavigationContainer, DefaultTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';

import HomeScreen from '../screens/HomeScreen';
import CatalogScreen from '../screens/CatalogScreen';
import SearchScreen from '../screens/SearchScreen';
import FavoritesScreen from '../screens/FavoritesScreen';
import ProfileScreen from '../screens/ProfileScreen';
import BookDetailScreen from '../screens/BookDetailScreen';
import AddBookScreen from '../screens/AddBookScreen';
import EditBookScreen from '../screens/EditBookScreen';
import { useApp } from '../context/AppContext';
import { colors } from '../theme';

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

const theme = {
  ...DefaultTheme,
  colors: { ...DefaultTheme.colors, background: colors.bg, primary: colors.primary },
};

const ICONS = {
  Accueil: ['home', 'home-outline'],
  Catalogue: ['library', 'library-outline'],
  Recherche: ['search', 'search-outline'],
  Favoris: ['heart', 'heart-outline'],
  Profil: ['person', 'person-outline'],
};

function Tabs() {
  const { favorites } = useApp();
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.muted,
        tabBarIcon: ({ focused, color, size }) => (
          <Ionicons name={ICONS[route.name][focused ? 0 : 1]} size={size} color={color} />
        ),
      })}
    >
      <Tab.Screen name="Accueil" component={HomeScreen} />
      <Tab.Screen name="Catalogue" component={CatalogScreen} />
      <Tab.Screen name="Recherche" component={SearchScreen} />
      <Tab.Screen
        name="Favoris"
        component={FavoritesScreen}
        options={{ tabBarBadge: favorites.length > 0 ? favorites.length : undefined }}
      />
      <Tab.Screen name="Profil" component={ProfileScreen} />
    </Tab.Navigator>
  );
}

export default function AppNavigator() {
  return (
    <NavigationContainer theme={theme}>
      <Stack.Navigator
        screenOptions={{
          headerTintColor: colors.dark,
          headerStyle: { backgroundColor: colors.bg },
          headerShadowVisible: false,
          headerBackTitle: 'Retour',
        }}
      >
        <Stack.Screen name="Tabs" component={Tabs} options={{ headerShown: false }} />
        <Stack.Screen name="BookDetail" component={BookDetailScreen} options={{ title: 'Détail du livre' }} />
        <Stack.Screen name="AddBook" component={AddBookScreen} options={{ title: 'Ajouter un livre' }} />
        <Stack.Screen name="EditBook" component={EditBookScreen} options={{ title: 'Modifier un livre' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
