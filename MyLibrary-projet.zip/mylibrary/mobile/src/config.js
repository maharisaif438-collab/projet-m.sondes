import { Platform } from 'react-native';

// Adresse de l'API REST (backend Node/Express).
//  - Émulateur Android : 10.0.2.2 désigne l'ordinateur hôte.
//  - Simulateur iOS / web : localhost.
//  - Téléphone réel (Expo Go) : utilisez l'adresse IP locale de votre PC, par exemple
//      EXPO_PUBLIC_API_URL=http://192.168.1.20:3000 npx expo start
const defaultHost = Platform.OS === 'android' ? '10.0.2.2' : 'localhost';

export const API_URL = process.env.EXPO_PUBLIC_API_URL || `http://${defaultHost}:3000`;
