import React, { useCallback, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import Cover from '../components/Cover';
import { useApp } from '../context/AppContext';
import * as api from '../api';
import { colors, radius } from '../theme';

export default function HomeScreen({ navigation }) {
  const { user, favorites, offline } = useApp();
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    try {
      setError(null);
      setBooks(await api.getBooks());
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const actions = [
    { icon: 'library', label: 'Catalogue', onPress: () => navigation.navigate('Catalogue') },
    { icon: 'search', label: 'Recherche', onPress: () => navigation.navigate('Recherche') },
    { icon: 'add-circle', label: 'Ajouter', onPress: () => navigation.navigate('AddBook') },
  ];

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <ScrollView contentContainerStyle={styles.content}>
        <View style={styles.hero}>
          <Text style={styles.hello}>Bonjour {user ? user.nom : ''} 👋</Text>
          <Text style={styles.subtitle}>Bienvenue dans MyLibrary</Text>
          <View style={styles.stats}>
            <View style={styles.stat}>
              <Text style={styles.statValue}>{books.length}</Text>
              <Text style={styles.statLabel}>livres</Text>
            </View>
            <View style={styles.stat}>
              <Text style={styles.statValue}>{favorites.length}</Text>
              <Text style={styles.statLabel}>favoris</Text>
            </View>
          </View>
        </View>

        {(error || offline) && (
          <View style={styles.banner}>
            <Ionicons name="cloud-offline" size={18} color={colors.danger} />
            <Text style={styles.bannerText}>{error || 'Serveur injoignable : données locales affichées.'}</Text>
          </View>
        )}

        <View style={styles.actions}>
          {actions.map((a) => (
            <Pressable key={a.label} style={styles.action} onPress={a.onPress}>
              <View style={styles.actionIcon}>
                <Ionicons name={a.icon} size={24} color="#fff" />
              </View>
              <Text style={styles.actionLabel}>{a.label}</Text>
            </Pressable>
          ))}
        </View>

        <Text style={styles.section}>Derniers ajouts</Text>
        {loading ? (
          <ActivityIndicator color={colors.primary} style={{ marginTop: 20 }} />
        ) : books.length === 0 ? (
          <Text style={styles.empty}>Aucun livre pour le moment.</Text>
        ) : (
          <FlatList
            data={books.slice(0, 8)}
            horizontal
            showsHorizontalScrollIndicator={false}
            keyExtractor={(b) => b.id}
            contentContainerStyle={{ paddingHorizontal: 16, gap: 14 }}
            renderItem={({ item }) => (
              <Pressable
                style={styles.recent}
                onPress={() => navigation.navigate('BookDetail', { id: item.id })}
              >
                <Cover book={item} width={110} height={150} radius={12} />
                <Text style={styles.recentTitle} numberOfLines={2}>
                  {item.titre}
                </Text>
                <Text style={styles.recentAuthor} numberOfLines={1}>
                  {item.auteur}
                </Text>
              </Pressable>
            )}
          />
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  content: { paddingBottom: 30 },
  hero: {
    backgroundColor: colors.dark,
    margin: 16,
    borderRadius: 20,
    padding: 20,
  },
  hello: { color: '#fff', fontSize: 24, fontWeight: '800' },
  subtitle: { color: '#BFD3CC', fontSize: 15, marginTop: 4 },
  stats: { flexDirection: 'row', gap: 12, marginTop: 18 },
  stat: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.12)',
    borderRadius: 14,
    paddingVertical: 12,
    alignItems: 'center',
  },
  statValue: { color: colors.accent, fontSize: 26, fontWeight: '800' },
  statLabel: { color: '#fff', fontSize: 13 },
  banner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#FBE9E5',
    marginHorizontal: 16,
    borderRadius: 12,
    padding: 12,
  },
  bannerText: { flex: 1, color: colors.danger, fontSize: 13 },
  actions: { flexDirection: 'row', gap: 12, paddingHorizontal: 16, marginTop: 16 },
  action: {
    flex: 1,
    backgroundColor: colors.card,
    borderRadius: radius,
    alignItems: 'center',
    paddingVertical: 16,
  },
  actionIcon: {
    width: 46,
    height: 46,
    borderRadius: 23,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  actionLabel: { fontSize: 14, fontWeight: '700', color: colors.dark },
  section: { fontSize: 20, fontWeight: '800', color: colors.dark, margin: 16, marginBottom: 12 },
  empty: { color: colors.muted, marginHorizontal: 16 },
  recent: { width: 110 },
  recentTitle: { fontSize: 14, fontWeight: '700', color: colors.text, marginTop: 8 },
  recentAuthor: { fontSize: 12, color: colors.muted },
});
