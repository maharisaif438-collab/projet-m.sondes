import React from 'react';
import { Alert, FlatList, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import BookCard from '../components/BookCard';
import { useApp } from '../context/AppContext';
import { colors } from '../theme';

export default function FavoritesScreen({ navigation }) {
  const { favorites, toggleFavorite } = useApp();

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <Text style={styles.title}>Mes favoris</Text>
      <FlatList
        data={favorites}
        keyExtractor={(b) => b.id}
        contentContainerStyle={styles.list}
        renderItem={({ item }) => (
          <BookCard
            book={item}
            isFavorite
            onToggleFavorite={() => toggleFavorite(item).catch((e) => Alert.alert('Erreur', e.message))}
            onPress={() => navigation.navigate('BookDetail', { id: item.id })}
          />
        )}
        ListEmptyComponent={
          <View style={styles.emptyBox}>
            <Ionicons name="heart-outline" size={48} color={colors.muted} />
            <Text style={styles.emptyText}>
              Aucun favori pour le moment. Touchez le cœur d'un livre pour l'ajouter ici.
            </Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  title: { fontSize: 28, fontWeight: '800', color: colors.dark, marginHorizontal: 16, marginTop: 8 },
  list: { padding: 16 },
  emptyBox: { alignItems: 'center', marginTop: 60, paddingHorizontal: 30 },
  emptyText: { color: colors.muted, marginTop: 12, textAlign: 'center', lineHeight: 20 },
});
