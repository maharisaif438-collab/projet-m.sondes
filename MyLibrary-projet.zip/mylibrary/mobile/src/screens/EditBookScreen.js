import React from 'react';
import BookForm from '../components/BookForm';
import { useApp } from '../context/AppContext';
import * as api from '../api';

export default function EditBookScreen({ route, navigation }) {
  const { book } = route.params;
  const { addHistory, syncBook } = useApp();

  const handleSubmit = async (data) => {
    const updated = await api.updateBook(book.id, data);
    syncBook(updated);
    addHistory('edit', updated.titre);
    navigation.goBack(); // la fiche se recharge toute seule au retour
  };

  return <BookForm initial={book} submitLabel="Enregistrer les modifications" onSubmit={handleSubmit} />;
}
