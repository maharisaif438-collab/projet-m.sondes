import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import BookCard from '../components/BookCard';
import { useApp } from '../context/AppContext';
import * as api from '../api';
import { colors } from '../theme';

export default function SearchScreen({ navigation }) {
  const { isFavorite, toggleFavorite } = useApp();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Recherche par titre ou auteur, déclenchée 300 ms après la dernière frappe
  useEffect(() => {
    const q = query.trim();
    if (!q) {
      setResults([]);
      setError(null);
      setLoading(false);
      return undefined;
    }
    let cancelled = false;
    setLoading(true);
    const timer = setTimeout(async () => {
      try {
        const found = await api.getBooks({ q });
        if (!cancelled) {
          setResults(found);
          setError(null);
        }
      } catch (e) {
        if (!cancelled) setError(e.message);
      } finally {
        if (!cancelled) setLoading(false);
      }
    }, 300);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [query]);

  const onFavorite = (book) => toggleFavorite(book).catch((e) => Alert.alert('Erreur', e.message));
  const hasQuery = query.trim().length > 0;

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <Text style={styles.title}>Recherche</Text>
      <View style={styles.searchBox}>
        <Ionicons name="search" size={20} color={colors.muted} />
        <TextInput
          style={styles.input}
          value={query}
          onChangeText={setQuery}
          placeholder="Titre ou auteur"
          placeholderTextColor={colors.muted}
          autoCorrect={false}
          returnKeyType="search"
        />
        {hasQuery && (
          <Pressable onPress={() => setQuery('')} hitSlop={10}>
            <Ionicons name="close-circle" size={20} color={colors.muted} />
          </Pressable>
        )}
      </View>

      {loading && <ActivityIndicator color={colors.primary} style={{ marginTop: 20 }} />}

      <FlatList
        data={results}
        keyExtractor={(b) => b.id}
        contentContainerStyle={styles.list}
        keyboardShouldPersistTaps="handled"
        renderItem={({ item }) => (
          <BookCard
            book={item}
            isFavorite={isFavorite(item.id)}
            onToggleFavorite={() => onFavorite(item)}
            onPress={() => navigation.navigate('BookDetail', { id: item.id })}
          />
        )}
        ListEmptyComponent={
          loading ? null : (
            <View style={styles.emptyBox}>
              <Ionicons
                name={error ? 'cloud-offline' : hasQuery ? 'sad-outline' : 'search-outline'}
                size={44}
                color={colors.muted}
              />
              <Text style={styles.emptyText}>
                {error ||
                  (hasQuery ? 'Aucun résultat pour cette recherche.' : 'Tapez un titre ou un auteur pour commencer.')}
              </Text>
            </View>
          )
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  title: { fontSize: 28, fontWeight: '800', color: colors.dark, marginHorizontal: 16, marginTop: 8 },
  searchBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: colors.card,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: colors.border,
    marginHorizontal: 16,
    marginTop: 12,
    paddingHorizontal: 14,
  },
  input: { flex: 1, paddingVertical: 12, fontSize: 16, color: colors.text },
  list: { padding: 16 },
  emptyBox: { alignItems: 'center', marginTop: 50, paddingHorizontal: 30 },
  emptyText: { color: colors.muted, marginTop: 12, textAlign: 'center' },
});
