import React from 'react';
import BookForm from '../components/BookForm';
import { useApp } from '../context/AppContext';
import * as api from '../api';

export default function AddBookScreen({ navigation }) {
  const { addHistory } = useApp();

  const handleSubmit = async (data) => {
    const created = await api.createBook(data);
    addHistory('add', created.titre);
    // remplace le formulaire par la fiche du livre qui vient d'être créé
    navigation.replace('BookDetail', { id: created.id });
  };

  return <BookForm submitLabel="Ajouter le livre" onSubmit={handleSubmit} />;
}
