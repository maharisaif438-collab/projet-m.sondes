import React, { useCallback, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import Cover from '../components/Cover';
import { useApp } from '../context/AppContext';
import * as api from '../api';
import { colors, radius } from '../theme';

export default function BookDetailScreen({ route, navigation }) {
  const { id } = route.params;
  const { isFavorite, toggleFavorite, addHistory, syncBook, dropBook } = useApp();
  const [book, setBook] = useState(null);
  const [error, setError] = useState(null);
  const [deleting, setDeleting] = useState(false);
  const viewLogged = useRef(false);

  // recharge à chaque retour sur l'écran (par exemple après une modification)
  useFocusEffect(
    useCallback(() => {
      let cancelled = false;
      api
        .getBook(id)
        .then((b) => {
          if (cancelled) return;
          setBook(b);
          setError(null);
          syncBook(b);
          if (!viewLogged.current) {
            viewLogged.current = true;
            addHistory('view', b.titre);
          }
        })
        .catch((e) => !cancelled && setError(e.message));
      return () => {
        cancelled = true;
      };
    }, [id, addHistory, syncBook])
  );

  const onFavorite = () => toggleFavorite(book).catch((e) => Alert.alert('Erreur', e.message));

  const confirmDelete = () => {
    Alert.alert('Supprimer ce livre ?', `« ${book.titre} » sera définitivement supprimé du catalogue.`, [
      { text: 'Annuler', style: 'cancel' },
      {
        text: 'Supprimer',
        style: 'destructive',
        onPress: async () => {
          setDeleting(true);
          try {
            await api.deleteBook(book.id);
            dropBook(book.id);
            addHistory('delete', book.titre);
            navigation.goBack();
          } catch (e) {
            setDeleting(false);
            Alert.alert('Erreur', e.message);
          }
        },
      },
    ]);
  };

  if (error && !book) {
    return (
      <View style={styles.center}>
        <Ionicons name="alert-circle" size={44} color={colors.danger} />
        <Text style={styles.errorText}>{error}</Text>
      </View>
    );
  }
  if (!book) {
    return (
      <View style={styles.center}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  const favorite = isFavorite(book.id);

  return (
    <ScrollView style={{ backgroundColor: colors.bg }} contentContainerStyle={styles.content}>
      <View style={styles.coverBox}>
        <Cover book={book} width={170} height={230} radius={14} />
      </View>

      <Text style={styles.title}>{book.titre}</Text>
      <Text style={styles.author}>{book.auteur}</Text>

      <View style={styles.meta}>
        <View style={styles.badge}>
          <Text style={styles.badgeText}>{book.categorie}</Text>
        </View>
        {!!book.annee && (
          <View style={[styles.badge, { backgroundColor: '#FBF1D6' }]}>
            <Text style={[styles.badgeText, { color: '#8A6F3E' }]}>{book.annee}</Text>
          </View>
        )}
      </View>

      <Text style={styles.sectionTitle}>Description</Text>
      <Text style={styles.description}>{book.description || 'Aucune description.'}</Text>

      <Pressable style={[styles.button, favorite ? styles.buttonFavOn : styles.buttonFav]} onPress={onFavorite}>
        <Ionicons name={favorite ? 'heart' : 'heart-outline'} size={20} color={favorite ? '#fff' : colors.danger} />
        <Text style={[styles.buttonText, !favorite && { color: colors.danger }]}>
          {favorite ? 'Retirer des favoris' : 'Ajouter aux favoris'}
        </Text>
      </Pressable>

      <View style={styles.row}>
        <Pressable
          style={[styles.button, styles.half, { backgroundColor: colors.primary }]}
          onPress={() => navigation.navigate('EditBook', { book })}
        >
          <Ionicons name="create-outline" size={20} color="#fff" />
          <Text style={styles.buttonText}>Modifier</Text>
        </Pressable>
        <Pressable
          style={[styles.button, styles.half, { backgroundColor: colors.danger }, deleting && { opacity: 0.6 }]}
          onPress={confirmDelete}
          disabled={deleting}
        >
          <Ionicons name="trash-outline" size={20} color="#fff" />
          <Text style={styles.buttonText}>Supprimer</Text>
        </Pressable>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.bg, padding: 30 },
  errorText: { color: colors.danger, textAlign: 'center', marginTop: 12 },
  content: { padding: 20, paddingBottom: 40 },
  coverBox: { alignItems: 'center', marginBottom: 20 },
  title: { fontSize: 26, fontWeight: '800', color: colors.dark, textAlign: 'center' },
  author: { fontSize: 16, color: colors.muted, textAlign: 'center', marginTop: 4 },
  meta: { flexDirection: 'row', justifyContent: 'center', gap: 8, marginTop: 14 },
  badge: { backgroundColor: colors.tint, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 5 },
  badgeText: { color: colors.primary, fontWeight: '700', fontSize: 13 },
  sectionTitle: { fontSize: 18, fontWeight: '800', color: colors.dark, marginTop: 24, marginBottom: 6 },
  description: { fontSize: 15, lineHeight: 22, color: colors.text },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    borderRadius: radius,
    paddingVertical: 14,
    marginTop: 14,
  },
  buttonFav: { backgroundColor: '#FBE9E5' },
  buttonFavOn: { backgroundColor: colors.danger },
  buttonText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  row: { flexDirection: 'row', gap: 12 },
  half: { flex: 1 },
});
