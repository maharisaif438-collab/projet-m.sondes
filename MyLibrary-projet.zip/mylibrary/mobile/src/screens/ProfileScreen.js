import React, { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useApp } from '../context/AppContext';
import { API_URL } from '../config';
import { colors, radius } from '../theme';

const HISTORY_TYPES = {
  view: { label: 'Consulté', icon: 'eye-outline', color: colors.muted },
  add: { label: 'Ajouté', icon: 'add-circle-outline', color: colors.primary },
  edit: { label: 'Modifié', icon: 'create-outline', color: '#3F5E8C' },
  delete: { label: 'Supprimé', icon: 'trash-outline', color: colors.danger },
  favorite: { label: 'Ajouté aux favoris', icon: 'heart', color: colors.danger },
  unfavorite: { label: 'Retiré des favoris', icon: 'heart-dislike-outline', color: colors.muted },
};

const formatDate = (iso) =>
  new Date(iso).toLocaleString('fr-FR', {
    day: '2-digit',
    month: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });

export default function ProfileScreen() {
  const { user, history, clearHistory, saveUser, offline } = useApp();
  const [nom, setNom] = useState('');
  const [email, setEmail] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (user) {
      setNom(user.nom);
      setEmail(user.email);
    }
  }, [user]);

  const save = async () => {
    if (!nom.trim() || !email.trim()) {
      Alert.alert('Champs manquants', 'Le nom et l\'email sont obligatoires.');
      return;
    }
    setSaving(true);
    try {
      await saveUser({ nom: nom.trim(), email: email.trim() });
      Alert.alert('Profil enregistré', 'Vos informations ont été mises à jour.');
    } catch (e) {
      Alert.alert('Erreur', e.message);
    } finally {
      setSaving(false);
    }
  };

  const confirmClear = () =>
    Alert.alert("Vider l'historique ?", 'Cette action est définitive.', [
      { text: 'Annuler', style: 'cancel' },
      { text: 'Vider', style: 'destructive', onPress: clearHistory },
    ]);

  const header = (
    <View>
      <Text style={styles.title}>Profil</Text>
      <View style={styles.card}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>{(nom || '?').charAt(0).toUpperCase()}</Text>
        </View>

        <Text style={styles.label}>Nom</Text>
        <TextInput style={styles.input} value={nom} onChangeText={setNom} placeholder="Votre nom" />
        <Text style={styles.label}>Email</Text>
        <TextInput
          style={styles.input}
          value={email}
          onChangeText={setEmail}
          placeholder="vous@exemple.com"
          keyboardType="email-address"
          autoCapitalize="none"
          autoCorrect={false}
        />
        <Pressable style={[styles.save, saving && { opacity: 0.6 }]} onPress={save} disabled={saving}>
          {saving ? <ActivityIndicator color="#fff" /> : <Text style={styles.saveText}>Enregistrer</Text>}
        </Pressable>

        <Text style={styles.server}>
          Serveur : {API_URL} {offline ? '(injoignable)' : '(connecté)'}
        </Text>
      </View>

      <View style={styles.historyHeader}>
        <Text style={styles.section}>Historique</Text>
        {history.length > 0 && (
          <Pressable onPress={confirmClear} hitSlop={10}>
            <Text style={styles.clear}>Vider</Text>
          </Pressable>
        )}
      </View>
    </View>
  );

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <FlatList
        data={history}
        keyExtractor={(h) => h.id}
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={styles.list}
        ListHeaderComponent={header}
        renderItem={({ item }) => {
          const t = HISTORY_TYPES[item.type] || HISTORY_TYPES.view;
          return (
            <View style={styles.historyRow}>
              <Ionicons name={t.icon} size={22} color={t.color} />
              <View style={{ flex: 1, marginLeft: 12 }}>
                <Text style={styles.historyTitle} numberOfLines={1}>
                  {item.titre}
                </Text>
                <Text style={styles.historyMeta}>{t.label}</Text>
              </View>
              <Text style={styles.historyDate}>{formatDate(item.date)}</Text>
            </View>
          );
        }}
        ListEmptyComponent={<Text style={styles.empty}>Aucune activité pour le moment.</Text>}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  list: { padding: 16, paddingBottom: 40 },
  title: { fontSize: 28, fontWeight: '800', color: colors.dark, marginBottom: 12 },
  card: { backgroundColor: colors.card, borderRadius: radius, padding: 16 },
  avatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    alignSelf: 'center',
    marginBottom: 8,
  },
  avatarText: { color: '#fff', fontSize: 28, fontWeight: '800' },
  label: { fontSize: 14, fontWeight: '700', color: colors.dark, marginTop: 12, marginBottom: 6 },
  input: {
    backgroundColor: colors.bg,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 11,
    fontSize: 16,
    color: colors.text,
  },
  save: {
    backgroundColor: colors.dark,
    borderRadius: radius,
    alignItems: 'center',
    paddingVertical: 13,
    marginTop: 18,
  },
  saveText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  server: { color: colors.muted, fontSize: 12, marginTop: 14, textAlign: 'center' },
  historyHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 24,
    marginBottom: 10,
  },
  section: { fontSize: 20, fontWeight: '800', color: colors.dark },
  clear: { color: colors.danger, fontWeight: '700' },
  historyRow: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: colors.card,
    borderRadius: 12,
    padding: 12,
    marginBottom: 8,
  },
  historyTitle: { fontSize: 15, fontWeight: '700', color: colors.text },
  historyMeta: { fontSize: 12, color: colors.muted, marginTop: 2 },
  historyDate: { fontSize: 12, color: colors.muted },
  empty: { color: colors.muted, textAlign: 'center', marginTop: 16 },
});
