import React, { useCallback, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Pressable,
  RefreshControl,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { SafeAreaView } from 'react-native-safe-area-context';
import BookCard from '../components/BookCard';
import CategoryChips from '../components/CategoryChips';
import { useApp } from '../context/AppContext';
import * as api from '../api';
import { colors } from '../theme';

export default function CatalogScreen({ navigation }) {
  const { isFavorite, toggleFavorite } = useApp();
  const [books, setBooks] = useState([]);
  const [categories, setCategories] = useState([]);
  const [selected, setSelected] = useState(null); // catégorie filtrée (null = toutes)
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    try {
      setError(null);
      const [list, cats] = await Promise.all([
        api.getBooks({ categorie: selected }),
        api.getCategories(),
      ]);
      setBooks(list);
      setCategories(cats);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [selected]);

  // recharge au retour sur l'écran et à chaque changement de filtre
  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const onFavorite = (book) => toggleFavorite(book).catch((e) => Alert.alert('Erreur', e.message));

  return (
    <SafeAreaView style={styles.safe} edges={['top']}>
      <Text style={styles.title}>Catalogue</Text>
      <CategoryChips categories={categories} selected={selected} onSelect={setSelected} />

      {loading ? (
        <ActivityIndicator color={colors.primary} style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={books}
          keyExtractor={(b) => b.id}
          contentContainerStyle={styles.list}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={() => {
                setRefreshing(true);
                load();
              }}
              tintColor={colors.primary}
            />
          }
          renderItem={({ item }) => (
            <BookCard
              book={item}
              isFavorite={isFavorite(item.id)}
              onToggleFavorite={() => onFavorite(item)}
              onPress={() => navigation.navigate('BookDetail', { id: item.id })}
            />
          )}
          ListEmptyComponent={
            <View style={styles.emptyBox}>
              <Ionicons name={error ? 'cloud-offline' : 'book-outline'} size={44} color={colors.muted} />
              <Text style={styles.emptyText}>
                {error || (selected ? 'Aucun livre dans cette catégorie.' : 'Le catalogue est vide.')}
              </Text>
            </View>
          }
        />
      )}

      <Pressable style={styles.fab} onPress={() => navigation.navigate('AddBook')}>
        <Ionicons name="add" size={30} color="#fff" />
      </Pressable>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.bg },
  title: { fontSize: 28, fontWeight: '800', color: colors.dark, marginHorizontal: 16, marginTop: 8 },
  list: { padding: 16, paddingBottom: 100 },
  emptyBox: { alignItems: 'center', marginTop: 60, paddingHorizontal: 30 },
  emptyText: { color: colors.muted, marginTop: 12, textAlign: 'center' },
  fab: {
    position: 'absolute',
    right: 20,
    bottom: 24,
    width: 58,
    height: 58,
    borderRadius: 29,
    backgroundColor: colors.primary,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 5,
    shadowColor: '#000',
    shadowOpacity: 0.25,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
  },
});
