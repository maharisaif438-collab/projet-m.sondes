import { API_URL } from './config';

async function request(path, options = {}) {
  let response;
  try {
    response = await fetch(`${API_URL}${path}`, {
      headers: { 'Content-Type': 'application/json' },
      ...options,
    });
  } catch (e) {
    throw new Error(
      `Impossible de joindre le serveur (${API_URL}). Vérifiez que l'API est démarrée et que l'adresse est correcte.`
    );
  }

  const text = await response.text();
  let data = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch (e) {
      data = null;
    }
  }
  if (!response.ok) {
    throw new Error((data && data.message) || `Erreur ${response.status}`);
  }
  return data;
}

const queryString = (params) => {
  const parts = Object.entries(params)
    .filter(([, v]) => v !== undefined && v !== null && v !== '')
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`);
  return parts.length ? `?${parts.join('&')}` : '';
};

// ---- Livres : CRUD sur /books
export const getBooks = ({ q, categorie } = {}) => request(`/books${queryString({ q, categorie })}`);
export const getBook = (id) => request(`/books/${id}`);
export const createBook = (book) => request('/books', { method: 'POST', body: JSON.stringify(book) });
export const updateBook = (id, book) =>
  request(`/books/${id}`, { method: 'PUT', body: JSON.stringify(book) });
export const deleteBook = (id) => request(`/books/${id}`, { method: 'DELETE' });
export const getCategories = () => request('/books/categories');

// ---- Utilisateurs
export const createUser = (user) => request('/users', { method: 'POST', body: JSON.stringify(user) });
export const updateUser = (id, user) =>
  request(`/users/${id}`, { method: 'PUT', body: JSON.stringify(user) });

// ---- Favoris
export const getFavorites = (utilisateur) => request(`/favorites${queryString({ utilisateur })}`);
export const addFavorite = (utilisateur, livre) =>
  request('/favorites', { method: 'POST', body: JSON.stringify({ utilisateur, livre }) });
export const removeFavorite = (utilisateur, livre) =>
  request(`/favorites${queryString({ utilisateur, livre })}`, { method: 'DELETE' });
