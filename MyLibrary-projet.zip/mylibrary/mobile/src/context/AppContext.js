import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as api from '../api';

// Clés AsyncStorage : sauvegarde locale du profil, des favoris et de l'historique
const KEYS = {
  user: 'mylibrary:user',
  favorites: 'mylibrary:favorites',
  history: 'mylibrary:history',
};

const DEFAULT_USER = { nom: 'Invité', email: 'invite@mylibrary.app' };
const MAX_HISTORY = 100;

const AppContext = createContext(null);

export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp doit être utilisé à l\'intérieur de AppProvider');
  return ctx;
};

const parse = (raw, fallback) => {
  try {
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) {
    return fallback;
  }
};

const save = (key, value) => AsyncStorage.setItem(key, JSON.stringify(value)).catch(() => {});

export function AppProvider({ children }) {
  const [user, setUser] = useState(null);
  const [favorites, setFavorites] = useState([]); // livres favoris (objets complets)
  const [history, setHistory] = useState([]);
  const [ready, setReady] = useState(false);
  const [offline, setOffline] = useState(false);

  // Au démarrage : lecture de la sauvegarde locale, puis synchronisation avec l'API
  useEffect(() => {
    let cancelled = false;
    (async () => {
      let localUser = null;
      try {
        const [u, f, h] = await Promise.all([
          AsyncStorage.getItem(KEYS.user),
          AsyncStorage.getItem(KEYS.favorites),
          AsyncStorage.getItem(KEYS.history),
        ]);
        localUser = parse(u, null);
        if (!cancelled) {
          setUser(localUser);
          setFavorites(parse(f, []));
          setHistory(parse(h, []));
        }
      } catch (e) {
        // sauvegarde locale illisible : on repart de zéro
      }

      try {
        const remoteUser = await api.createUser(
          localUser ? { nom: localUser.nom, email: localUser.email } : DEFAULT_USER
        );
        const remoteFavorites = await api.getFavorites(remoteUser.id);
        if (!cancelled) {
          setUser(remoteUser);
          setFavorites(remoteFavorites.map((f) => f.livre));
          setOffline(false);
        }
      } catch (e) {
        if (!cancelled) setOffline(true);
      }
      if (!cancelled) setReady(true);
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  // Sauvegarde locale à chaque changement (une fois le chargement initial terminé)
  useEffect(() => {
    if (ready && user) save(KEYS.user, user);
  }, [user, ready]);
  useEffect(() => {
    if (ready) save(KEYS.favorites, favorites);
  }, [favorites, ready]);
  useEffect(() => {
    if (ready) save(KEYS.history, history);
  }, [history, ready]);

  const addHistory = useCallback((type, titre) => {
    const entry = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      type,
      titre,
      date: new Date().toISOString(),
    };
    setHistory((prev) => [entry, ...prev].slice(0, MAX_HISTORY));
  }, []);

  const clearHistory = useCallback(() => setHistory([]), []);

  const isFavorite = useCallback((id) => favorites.some((b) => b.id === id), [favorites]);

  // Ajoute ou retire un favori (mise à jour immédiate, annulée si l'API échoue)
  const toggleFavorite = useCallback(
    async (book) => {
      const previous = favorites;
      const already = previous.some((b) => b.id === book.id);
      setFavorites(already ? previous.filter((b) => b.id !== book.id) : [book, ...previous]);
      try {
        if (!user || !user.id) throw new Error('Profil indisponible : le serveur est injoignable.');
        if (already) await api.removeFavorite(user.id, book.id);
        else await api.addFavorite(user.id, book.id);
        addHistory(already ? 'unfavorite' : 'favorite', book.titre);
      } catch (e) {
        setFavorites(previous);
        throw e;
      }
    },
    [favorites, user, addHistory]
  );

  // Garde les favoris cohérents quand un livre est modifié ou supprimé
  const syncBook = useCallback(
    (book) => setFavorites((prev) => prev.map((b) => (b.id === book.id ? book : b))),
    []
  );
  const dropBook = useCallback(
    (id) => setFavorites((prev) => prev.filter((b) => b.id !== id)),
    []
  );

  const saveUser = useCallback(
    async ({ nom, email }) => {
      const saved =
        user && user.id
          ? await api.updateUser(user.id, { nom, email })
          : await api.createUser({ nom, email });
      setUser(saved);
      setOffline(false);
      return saved;
    },
    [user]
  );

  const value = useMemo(
    () => ({
      user,
      favorites,
      history,
      ready,
      offline,
      isFavorite,
      toggleFavorite,
      addHistory,
      clearHistory,
      syncBook,
      dropBook,
      saveUser,
    }),
    [
      user,
      favorites,
      history,
      ready,
      offline,
      isFavorite,
      toggleFavorite,
      addHistory,
      clearHistory,
      syncBook,
      dropBook,
      saveUser,
    ]
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
