# MyLibrary — Documentation de conception

## 1. Contexte et objectif

Une bibliothèque souhaite proposer une application mobile pour consulter son catalogue, rechercher des ouvrages et gérer une liste de livres favoris. L'objectif est de développer une application permettant de **consulter et gérer un catalogue de livres**.

## 2. Besoins fonctionnels

| # | Besoin | Écran principal |
|---|---|---|
| F1 | Afficher les livres | Catalogue |
| F2 | Rechercher un livre | Recherche |
| F3 | Filtrer par catégorie | Catalogue |
| F4 | Afficher les détails d'un livre | Détail du livre |
| F5 | Ajouter un livre aux favoris | Catalogue, Recherche, Détail |
| F6 | Consulter les favoris | Favoris |
| F7 | Ajouter un livre (avec photo de couverture) | Ajouter un livre |
| F8 | Modifier un livre | Modifier un livre |
| F9 | Supprimer un livre | Détail du livre |
| F10 | Consulter l'historique | Profil |

Besoins non fonctionnels : interface simple en français, affichage des données locales si le serveur est injoignable, messages d'erreur clairs.

## 3. Cas d'utilisation

Acteur unique : **l'utilisateur** de la bibliothèque.

```mermaid
flowchart LR
  U([Utilisateur])
  U --> C[Consulter le catalogue]
  U --> R[Rechercher un livre]
  U --> FI[Filtrer par catégorie]
  U --> D[Afficher les détails]
  U --> FA[Gérer ses favoris]
  U --> A[Ajouter un livre]
  A -. inclut .-> P[Photographier la couverture]
  U --> M[Modifier un livre]
  U --> S[Supprimer un livre]
  U --> H[Consulter l'historique]
  U --> PR[Modifier son profil]
```

## 4. Architecture

```mermaid
flowchart LR
  subgraph Mobile["Application React Native (Expo)"]
    UI[Écrans + navigation]
    CTX[Context API<br/>profil, favoris, historique]
    AS[(AsyncStorage)]
    CAM[Caméra<br/>expo-image-picker]
    UI --> CTX --> AS
    UI --> CAM
  end
  API[API REST<br/>Node.js + Express]
  DB[(MongoDB<br/>books · users · favorites)]
  UI -- HTTP / JSON --> API --> DB
  CTX -- HTTP / JSON --> API
```

- **Couche présentation** : écrans React Native (composants, Flexbox, `FlatList`).
- **Couche état** : `AppContext` (Context API) partage profil, favoris et historique entre les écrans ; `AsyncStorage` en garde une copie locale.
- **Couche accès aux données** : `src/api.js` centralise tous les appels `fetch` vers l'API.
- **Backend** : Express expose l'API REST, Mongoose valide et enregistre dans MongoDB.

## 5. Modèle de données

```mermaid
erDiagram
  USER ||--o{ FAVORITE : possede
  BOOK ||--o{ FAVORITE : "est favori de"
  BOOK {
    ObjectId id
    string titre
    string auteur
    string categorie
    number annee
    string description
    string image
  }
  USER {
    ObjectId id
    string nom
    string email
  }
  FAVORITE {
    ObjectId id
    ObjectId utilisateur
    ObjectId livre
  }
```

Collections MongoDB : `books`, `users`, `favorites` (voir `backend/models/`).

Règles :
- `titre`, `auteur`, `categorie` sont obligatoires pour un livre ; `annee` est un nombre facultatif.
- `email` est unique et validé ; `nom` est obligatoire.
- Un favori est unique pour le couple (`utilisateur`, `livre`) (index unique).
- Supprimer un livre supprime aussi ses favoris.
- Dans le JSON, `_id` MongoDB est renvoyé sous le nom `id`. Les noms de champs sont sans accent (`categorie`, `annee`) pour éviter les problèmes d'encodage.

## 6. API REST

Base : `http://<serveur>:3000`. Toutes les réponses sont en JSON ; les erreurs ont la forme `{ "message": "..." }`.

### Livres (CRUD complet sur la collection `books`)

| Méthode | Route | Corps | Réponse |
|---|---|---|---|
| GET | `/books` | – | `200` tableau de livres, du plus récent au plus ancien. Paramètres facultatifs : `q` (titre ou auteur), `categorie` |
| GET | `/books/categories` | – | `200` tableau de catégories |
| GET | `/books/:id` | – | `200` livre · `404` introuvable · `400` id invalide |
| POST | `/books` | `{ titre, auteur, categorie, annee?, description?, image? }` | `201` livre créé · `400` champ manquant |
| PUT | `/books/:id` | champs à modifier | `200` livre modifié · `404` · `400` |
| DELETE | `/books/:id` | – | `200 { message, id }` · `404` |

Exemple :

```http
POST /books
{ "titre": "Dune", "auteur": "Frank Herbert", "categorie": "Science-fiction", "annee": 1965 }
```

### Utilisateurs et favoris

| Méthode | Route | Description |
|---|---|---|
| POST | `/users` | Crée l'utilisateur, ou renvoie celui qui a le même email |
| GET / PUT | `/users/:id` | Lecture / mise à jour du profil |
| GET | `/favorites?utilisateur=ID` | Favoris de l'utilisateur, livre complet inclus |
| POST | `/favorites` | `{ utilisateur, livre }` : ajoute un favori (sans doublon) |
| DELETE | `/favorites?utilisateur=ID&livre=ID` | Retire un favori |
| DELETE | `/favorites/:id` | Retire un favori par son identifiant |

## 7. Navigation et écrans

```mermaid
flowchart TD
  T{{Onglets}} --> H[Accueil]
  T --> CA[Catalogue]
  T --> RE[Recherche]
  T --> FV[Favoris]
  T --> PF[Profil]
  H --> DT[Détail du livre]
  CA --> DT
  RE --> DT
  FV --> DT
  CA --> AD[Ajouter un livre]
  H --> AD
  AD --> DT
  DT --> ED[Modifier un livre]
  ED --> DT
  DT -- suppression --> CA
```

| Écran | Rôle |
|---|---|
| Accueil | Salutation, compteurs (livres, favoris), raccourcis, derniers ajouts |
| Catalogue | Liste `FlatList`, filtre par catégorie, bouton d'ajout, actualisation par tirage |
| Recherche | Champ de recherche (titre ou auteur) avec délai de 300 ms |
| Détail du livre | Couverture, informations, favori, modification, suppression avec confirmation |
| Ajouter / Modifier un livre | Formulaire commun, validation, photo de couverture par la caméra |
| Favoris | Livres favoris de l'utilisateur |
| Profil | Nom et email, historique des actions |

## 8. Gestion d'état

- **`AppContext`** fournit : `user`, `favorites`, `history`, `isFavorite`, `toggleFavorite`, `addHistory`, `clearHistory`, `syncBook`, `dropBook`, `saveUser`.
- **Favoris** : mise à jour immédiate de l'interface, puis appel API ; en cas d'échec, l'état précédent est restauré et un message est affiché.
- **AsyncStorage** (clés `mylibrary:user`, `mylibrary:favorites`, `mylibrary:history`) : au lancement, les données locales s'affichent d'abord, puis l'application se synchronise avec le serveur.
- **`useState` / `useEffect`** : chargement des listes, recherche avec délai, rechargement au retour sur un écran (`useFocusEffect`).

## 9. Fonctionnalité native : caméra

Le formulaire d'ajout/modification appelle `expo-image-picker` (`launchCameraAsync`) après avoir demandé la permission. La photo est recadrée en 3:4, réduite à 400 px de large en JPEG (`expo-image-manipulator`), puis stockée en base64 dans le champ `image` du livre.

## 10. Historique

L'historique est un journal local (100 entrées maximum) des actions : consultation, ajout, modification, suppression, ajout ou retrait d'un favori. Il est alimenté depuis le Context et conservé dans AsyncStorage.

## 11. Limites et améliorations possibles

- Pas d'authentification : un profil par appareil, identifié par son email.
- Les images en base64 alourdissent les réponses ; à terme, stockage de fichiers (disque ou service cloud) et champ `image` contenant une URL.
- Historique propre à chaque appareil ; il pourrait être stocké côté serveur dans une collection `history`.
- Pagination de `GET /books` pour les gros catalogues.
- Tests automatisés de l'API et des écrans.
