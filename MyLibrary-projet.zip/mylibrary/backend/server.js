require('dotenv').config();
const mongoose = require('mongoose');
const app = require('./app');

const PORT = process.env.PORT || 3000;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/mylibrary';

mongoose
  .connect(MONGODB_URI)
  .then(() => {
    console.log('MongoDB connecté :', MONGODB_URI);
    // écoute sur toutes les interfaces pour que le téléphone puisse joindre l'API sur le réseau local
    app.listen(PORT, '0.0.0.0', () => console.log(`API MyLibrary sur http://localhost:${PORT}`));
  })
  .catch((err) => {
    console.error('Connexion MongoDB impossible :', err.message);
    process.exit(1);
  });
