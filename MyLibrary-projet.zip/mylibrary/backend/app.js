const express = require('express');
const cors = require('cors');

const booksRoutes = require('./routes/books');
const usersRoutes = require('./routes/users');
const favoritesRoutes = require('./routes/favorites');

const app = express();

app.use(cors());
// limite relevée : la photo de couverture est envoyée en base64 dans le champ "image"
app.use(express.json({ limit: '10mb' }));

app.get('/', (_req, res) => {
  res.json({ name: 'MyLibrary API', status: 'ok' });
});

app.use('/books', booksRoutes);
app.use('/users', usersRoutes);
app.use('/favorites', favoritesRoutes);

app.use((_req, res) => res.status(404).json({ message: 'Route introuvable' }));

// Gestion centralisée des erreurs
// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ message: 'Corps de requête JSON invalide' });
  }
  if (err.name === 'ValidationError') {
    const message = Object.values(err.errors).map((e) => e.message).join(', ');
    return res.status(400).json({ message });
  }
  if (err.name === 'CastError') {
    return res.status(400).json({ message: 'Valeur invalide' });
  }
  if (err.code === 11000) {
    return res.status(409).json({ message: 'Cet élément existe déjà' });
  }
  console.error(err);
  res.status(500).json({ message: 'Erreur interne du serveur' });
});

module.exports = app;
