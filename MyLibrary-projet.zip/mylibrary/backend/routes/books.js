const express = require('express');
const mongoose = require('mongoose');
const Book = require('../models/Book');
const Favorite = require('../models/Favorite');

const router = express.Router();

const escapeRegex = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const pick = (body) => {
  const { titre, auteur, categorie, annee, description, image } = body;
  const data = { titre, auteur, categorie, annee, description, image };
  // retire les champs non fournis pour ne pas écraser les valeurs existantes
  Object.keys(data).forEach((k) => data[k] === undefined && delete data[k]);
  return data;
};

const checkId = (req, res, next) => {
  if (!mongoose.isValidObjectId(req.params.id)) {
    return res.status(400).json({ message: 'Identifiant invalide' });
  }
  next();
};

// GET /books?q=...&categorie=...  -> liste (avec recherche et filtre facultatifs)
router.get('/', async (req, res, next) => {
  try {
    const filter = {};
    if (req.query.categorie) filter.categorie = req.query.categorie;
    if (req.query.q) {
      const rx = new RegExp(escapeRegex(String(req.query.q)), 'i');
      filter.$or = [{ titre: rx }, { auteur: rx }];
    }
    const books = await Book.find(filter).sort({ createdAt: -1 });
    res.json(books);
  } catch (err) {
    next(err);
  }
});

// GET /books/categories -> liste des catégories existantes
router.get('/categories', async (_req, res, next) => {
  try {
    const categories = await Book.distinct('categorie');
    res.json(categories.sort((a, b) => a.localeCompare(b, 'fr')));
  } catch (err) {
    next(err);
  }
});

// GET /books/:id -> détail d'un livre
router.get('/:id', checkId, async (req, res, next) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) return res.status(404).json({ message: 'Livre introuvable' });
    res.json(book);
  } catch (err) {
    next(err);
  }
});

// POST /books -> ajout
router.post('/', async (req, res, next) => {
  try {
    const book = await Book.create(pick(req.body));
    res.status(201).json(book);
  } catch (err) {
    next(err);
  }
});

// PUT /books/:id -> modification
router.put('/:id', checkId, async (req, res, next) => {
  try {
    const book = await Book.findByIdAndUpdate(req.params.id, pick(req.body), {
      new: true,
      runValidators: true,
    });
    if (!book) return res.status(404).json({ message: 'Livre introuvable' });
    res.json(book);
  } catch (err) {
    next(err);
  }
});

// DELETE /books/:id -> suppression (et des favoris associés)
router.delete('/:id', checkId, async (req, res, next) => {
  try {
    const book = await Book.findByIdAndDelete(req.params.id);
    if (!book) return res.status(404).json({ message: 'Livre introuvable' });
    await Favorite.deleteMany({ livre: book._id });
    res.json({ message: 'Livre supprimé', id: req.params.id });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
