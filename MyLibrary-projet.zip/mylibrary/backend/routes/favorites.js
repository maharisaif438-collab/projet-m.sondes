const express = require('express');
const mongoose = require('mongoose');
const Favorite = require('../models/Favorite');

const router = express.Router();

// GET /favorites?utilisateur=ID -> favoris d'un utilisateur (avec le livre complet)
router.get('/', async (req, res, next) => {
  try {
    const { utilisateur } = req.query;
    if (!mongoose.isValidObjectId(utilisateur)) {
      return res.status(400).json({ message: 'Paramètre "utilisateur" invalide' });
    }
    const favorites = await Favorite.find({ utilisateur })
      .sort({ createdAt: -1 })
      .populate('livre');
    // ignore les favoris dont le livre a été supprimé entre-temps
    res.json(favorites.filter((f) => f.livre));
  } catch (err) {
    next(err);
  }
});

// POST /favorites { utilisateur, livre } -> ajoute un favori (sans doublon)
router.post('/', async (req, res, next) => {
  try {
    const { utilisateur, livre } = req.body;
    if (!mongoose.isValidObjectId(utilisateur) || !mongoose.isValidObjectId(livre)) {
      return res.status(400).json({ message: 'utilisateur et livre sont obligatoires' });
    }
    const favorite = await Favorite.findOneAndUpdate(
      { utilisateur, livre },
      { utilisateur, livre },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );
    res.status(201).json(favorite);
  } catch (err) {
    next(err);
  }
});

// DELETE /favorites?utilisateur=ID&livre=ID -> retire un favori
router.delete('/', async (req, res, next) => {
  try {
    const { utilisateur, livre } = req.query;
    if (!mongoose.isValidObjectId(utilisateur) || !mongoose.isValidObjectId(livre)) {
      return res.status(400).json({ message: 'utilisateur et livre sont obligatoires' });
    }
    await Favorite.deleteOne({ utilisateur, livre });
    res.json({ message: 'Favori retiré' });
  } catch (err) {
    next(err);
  }
});

// DELETE /favorites/:id -> retire un favori par son identifiant
router.delete('/:id', async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: 'Identifiant invalide' });
    }
    const favorite = await Favorite.findByIdAndDelete(req.params.id);
    if (!favorite) return res.status(404).json({ message: 'Favori introuvable' });
    res.json({ message: 'Favori retiré' });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
