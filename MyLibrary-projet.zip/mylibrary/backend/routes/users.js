const express = require('express');
const mongoose = require('mongoose');
const User = require('../models/User');

const router = express.Router();

// POST /users -> crée l'utilisateur, ou le retrouve s'il existe déjà (même email)
router.post('/', async (req, res, next) => {
  try {
    const { nom, email } = req.body;
    if (!email) return res.status(400).json({ message: "L'email est obligatoire" });
    let user = await User.findOne({ email: String(email).toLowerCase().trim() });
    if (user) return res.json(user);
    user = await User.create({ nom, email });
    res.status(201).json(user);
  } catch (err) {
    next(err);
  }
});

// GET /users/:id
router.get('/:id', async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: 'Identifiant invalide' });
    }
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: 'Utilisateur introuvable' });
    res.json(user);
  } catch (err) {
    next(err);
  }
});

// PUT /users/:id -> modification du profil
router.put('/:id', async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(400).json({ message: 'Identifiant invalide' });
    }
    const { nom, email } = req.body;
    const data = {};
    if (nom !== undefined) data.nom = nom;
    if (email !== undefined) data.email = email;
    const user = await User.findByIdAndUpdate(req.params.id, data, {
      new: true,
      runValidators: true,
    });
    if (!user) return res.status(404).json({ message: 'Utilisateur introuvable' });
    res.json(user);
  } catch (err) {
    next(err);
  }
});

module.exports = router;
