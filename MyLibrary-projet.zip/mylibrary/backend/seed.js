require('dotenv').config();
const mongoose = require('mongoose');
const Book = require('./models/Book');
const User = require('./models/User');
const Favorite = require('./models/Favorite');

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/mylibrary';

const books = [
  {
    titre: 'Les Misérables',
    auteur: 'Victor Hugo',
    categorie: 'Roman',
    annee: 1862,
    description:
      "Fresque sociale de la France du XIXe siècle autour de Jean Valjean, ancien forçat en quête de rédemption, poursuivi par l'inspecteur Javert.",
  },
  {
    titre: "L'Étranger",
    auteur: 'Albert Camus',
    categorie: 'Roman',
    annee: 1942,
    description:
      "À Alger, Meursault assiste à l'enterrement de sa mère sans larmes, puis se retrouve jugé pour un meurtre. Un roman clé de la philosophie de l'absurde.",
  },
  {
    titre: 'Le Petit Prince',
    auteur: 'Antoine de Saint-Exupéry',
    categorie: 'Jeunesse',
    annee: 1943,
    description:
      "Un aviateur perdu dans le désert rencontre un petit garçon venu d'une autre planète. Un conte poétique sur l'amitié, l'amour et le regard des adultes.",
  },
  {
    titre: '1984',
    auteur: 'George Orwell',
    categorie: 'Science-fiction',
    annee: 1949,
    description:
      "Dans un État totalitaire où Big Brother surveille tout, Winston Smith tente de préserver sa liberté de penser. Une dystopie sur la surveillance et la manipulation.",
  },
  {
    titre: 'Dune',
    auteur: 'Frank Herbert',
    categorie: 'Science-fiction',
    annee: 1965,
    description:
      "Sur la planète désertique Arrakis, seule source de l'épice la plus précieuse de l'univers, le jeune Paul Atréides est entraîné dans une lutte de pouvoir.",
  },
  {
    titre: 'Fondation',
    auteur: 'Isaac Asimov',
    categorie: 'Science-fiction',
    annee: 1951,
    description:
      "Alors que l'Empire galactique décline, le mathématicien Hari Seldon met en place un plan pour raccourcir l'âge sombre qui s'annonce.",
  },
  {
    titre: 'Sapiens : une brève histoire de l\'humanité',
    auteur: 'Yuval Noah Harari',
    categorie: 'Histoire',
    annee: 2011,
    description:
      "Un parcours de l'histoire d'Homo sapiens, de la révolution cognitive à nos jours, à travers l'agriculture, les empires, la science et l'économie.",
  },
  {
    titre: 'Les Fleurs du mal',
    auteur: 'Charles Baudelaire',
    categorie: 'Poésie',
    annee: 1857,
    description:
      "Recueil majeur de la poésie moderne, entre spleen et idéal, qui explore la beauté, la ville, l'amour et la mort.",
  },
  {
    titre: 'Clean Code',
    auteur: 'Robert C. Martin',
    categorie: 'Informatique',
    annee: 2008,
    description:
      "Un guide de bonnes pratiques pour écrire du code lisible, simple à maintenir et à tester, avec de nombreux exemples de refactoring.",
  },
  {
    titre: 'Eloquent JavaScript',
    auteur: 'Marijn Haverbeke',
    categorie: 'Informatique',
    annee: 2011,
    description:
      "Une introduction moderne à JavaScript et à la programmation : langage, navigateur, Node.js et projets pratiques.",
  },
  {
    titre: 'Les Aventures de Tom Sawyer',
    auteur: 'Mark Twain',
    categorie: 'Jeunesse',
    annee: 1876,
    description:
      "Les espiègleries et les aventures d'un garçon des bords du Mississippi, entre jeux, trésor caché et témoin d'un crime.",
  },
  {
    titre: 'Une brève histoire du temps',
    auteur: 'Stephen Hawking',
    categorie: 'Sciences',
    annee: 1988,
    description:
      "Une présentation accessible de la cosmologie : Big Bang, trous noirs, nature du temps et recherche d'une théorie unifiée.",
  },
];

async function run() {
  await mongoose.connect(MONGODB_URI);
  await Promise.all([Book.deleteMany({}), Favorite.deleteMany({})]);
  const created = await Book.insertMany(books);
  await User.findOneAndUpdate(
    { email: 'invite@mylibrary.app' },
    { nom: 'Invité', email: 'invite@mylibrary.app' },
    { upsert: true, new: true, setDefaultsOnInsert: true }
  );
  console.log(`${created.length} livres insérés dans ${MONGODB_URI}`);
  await mongoose.disconnect();
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
