const mongoose = require('mongoose');

// Collection "favorites" : un favori relie un utilisateur à un livre
const favoriteSchema = new mongoose.Schema(
  {
    utilisateur: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    livre: { type: mongoose.Schema.Types.ObjectId, ref: 'Book', required: true },
  },
  { timestamps: true }
);

// Un utilisateur ne peut pas ajouter deux fois le même livre
favoriteSchema.index({ utilisateur: 1, livre: 1 }, { unique: true });

favoriteSchema.set('toJSON', {
  versionKey: false,
  transform: (_doc, ret) => {
    ret.id = ret._id.toString();
    delete ret._id;
    return ret;
  },
});

module.exports = mongoose.model('Favorite', favoriteSchema);
