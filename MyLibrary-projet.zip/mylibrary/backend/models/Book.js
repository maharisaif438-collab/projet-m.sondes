const mongoose = require('mongoose');

// Collection "books"
const bookSchema = new mongoose.Schema(
  {
    titre: { type: String, required: [true, 'Le titre est obligatoire'], trim: true },
    auteur: { type: String, required: [true, "L'auteur est obligatoire"], trim: true },
    categorie: { type: String, required: [true, 'La catégorie est obligatoire'], trim: true },
    annee: { type: Number, min: 0, max: 3000 },
    description: { type: String, default: '', trim: true },
    // URL ou data URI (base64) de la couverture, par exemple une photo prise avec la caméra
    image: { type: String, default: '' },
  },
  { timestamps: true }
);

// Expose "id" au lieu de "_id" dans le JSON renvoyé par l'API
bookSchema.set('toJSON', {
  versionKey: false,
  transform: (_doc, ret) => {
    ret.id = ret._id.toString();
    delete ret._id;
    return ret;
  },
});

module.exports = mongoose.model('Book', bookSchema);
