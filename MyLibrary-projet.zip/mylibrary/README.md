# MyLibrary — Application mobile de gestion d'une bibliothèque

Mini-projet 6 · DSI3 · ISET Gafsa

Application mobile **React Native (Expo)** pour consulter et gérer le catalogue d'une bibliothèque, avec un backend **Node.js / Express** et une base **MongoDB**.

```
mylibrary/
├── backend/   API REST (Express + Mongoose)
├── mobile/    Application React Native (Expo)
└── docs/      Documentation de conception
```

## Prérequis

- Node.js 20 ou plus récent
- MongoDB en local (`mongodb://127.0.0.1:27017`) ou une base MongoDB Atlas
- L'application **Expo Go** sur votre téléphone, ou un émulateur Android / un simulateur iOS

## 1. Lancer le backend

```bash
cd backend
npm install
cp .env.example .env        # puis adapter MONGODB_URI si besoin
npm run seed                # insère 12 livres d'exemple (collections books, users)
npm start                   # API sur http://localhost:3000
```

Test rapide : ouvrir `http://localhost:3000/books` dans un navigateur.

## 2. Lancer l'application mobile

```bash
cd mobile
npm install
npx expo install --fix      # aligne les versions des modules natifs sur votre SDK Expo
npx expo start
```

Puis scanner le QR code avec Expo Go (ou appuyer sur `a` pour Android, `i` pour iOS).

### Adresse de l'API

L'application doit joindre le backend. L'adresse se règle dans `mobile/src/config.js` :

| Cible | Adresse utilisée |
|---|---|
| Émulateur Android | `http://10.0.2.2:3000` (par défaut) |
| Simulateur iOS | `http://localhost:3000` (par défaut) |
| **Téléphone réel** | l'adresse IP locale de votre PC, par exemple `http://192.168.1.20:3000` |

Pour un téléphone réel, le PC et le téléphone doivent être sur le même Wi-Fi :

```bash
EXPO_PUBLIC_API_URL=http://192.168.1.20:3000 npx expo start
```

(sous Windows PowerShell : `$env:EXPO_PUBLIC_API_URL="http://192.168.1.20:3000"; npx expo start`)

L'écran **Profil** affiche l'adresse utilisée et l'état de la connexion.

> La caméra ne fonctionne pas dans le simulateur iOS ni dans un navigateur : utilisez un téléphone réel ou un émulateur Android avec caméra virtuelle.

## Fonctionnalités (cahier des charges)

| Fonctionnalité demandée | Où la trouver |
|---|---|
| Afficher les livres | Écran **Catalogue** (`FlatList`) |
| Rechercher un livre | Écran **Recherche** (titre ou auteur) |
| Filtrer par catégorie | Pastilles de catégories du **Catalogue** |
| Afficher les détails | Écran **Détail du livre** |
| Ajouter aux favoris / consulter les favoris | Cœur sur chaque livre, écran **Favoris** |
| Ajouter / modifier / supprimer un livre | Boutons **+**, **Modifier**, **Supprimer** |
| Consulter l'historique | Écran **Profil**, section Historique |
| Photographier la couverture | Formulaire d'ajout/modification (caméra) |

## API REST

| Méthode | Route | Description |
|---|---|---|
| GET | `/books` | Liste des livres (`?q=` recherche, `?categorie=` filtre) |
| GET | `/books/:id` | Détail d'un livre |
| POST | `/books` | Ajout d'un livre |
| PUT | `/books/:id` | Modification d'un livre |
| DELETE | `/books/:id` | Suppression d'un livre |
| GET | `/books/categories` | Catégories existantes |
| POST / PUT | `/users`, `/users/:id` | Création et mise à jour du profil |
| GET / POST / DELETE | `/favorites` | Favoris d'un utilisateur |

Les détails (corps des requêtes, codes d'erreur) sont dans [`docs/CONCEPTION.md`](docs/CONCEPTION.md).

## Scénario de démonstration (10 min)

1. **Catalogue** : montrer la liste et filtrer par catégorie.
2. **Recherche** : taper « dune » ou un nom d'auteur.
3. **Détail** : ouvrir un livre.
4. **Favoris** : ajouter le livre aux favoris, puis ouvrir l'onglet Favoris.
5. **Ajout d'un livre** : bouton **+** du catalogue.
6. **Photographie** : prendre la couverture avec la caméra, enregistrer.
7. **Modification** : modifier le livre créé.
8. **Suppression** : supprimer le livre, puis montrer l'historique dans **Profil**.

## Notes techniques

- **Context API** (`mobile/src/context/AppContext.js`) : profil, favoris et historique accessibles depuis tous les écrans.
- **AsyncStorage** : copie locale du profil, des favoris et de l'historique ; l'application affiche ces données même si le serveur est injoignable.
- **Photo de couverture** : réduite à 400 px de large puis envoyée en base64 dans le champ `image` du livre (simple pour un mini-projet ; en production on stockerait le fichier à part).
- **Historique** : journal local des actions (consultation, ajout, modification, suppression, favoris), conservé sur le téléphone.
